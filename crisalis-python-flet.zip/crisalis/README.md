# CRISALIS · «Es normal tener dudas»
App móvil (Android/iOS) escrita en **Python** con [Flet](https://flet.dev). Proyecto PEMO-04, CONALEP Plantel 244, Papantla.

## Estructura
- `src/main.py` – interfaz y navegación (clase `App`)
- `src/data.py` – artículos y reglas (offline)
- `src/db.py` – base de datos SQLite local
- `pyproject.toml` – configuración de compilación

## Probar en la computadora
    pip install -r requirements.txt
    flet run src/main.py

## Probar en tu celular
Instala la app **Flet** (Play Store / App Store) y ejecuta `flet run --android src/main.py` (o `--ios`) con el celular en la misma red Wi-Fi.

## Generar el APK / AAB
    flet build apk      # instalable directo
    flet build aab      # para Google Play
(La primera vez descarga Flutter y el SDK de Android automáticamente. Para iOS se necesita una Mac: `flet build ipa`.)

## Aviso ético
CRISALIS es una guía informativa y preventiva, no un diagnóstico. Los artículos deben ser validados por profesionales de la salud antes de publicarse.

## APK sin instalar nada en tu computadora (GitHub)
1. Crea un repositorio en github.com y sube el contenido de esta carpeta (incluida `.github`).
2. Pestaña **Actions** → **Generar APK de CRISALIS** → **Run workflow**.
3. Al terminar (10–20 min), descarga el artefacto `crisalis-apk` (zip) y pasa el `.apk` a tu celular.
4. En Android permite «instalar apps de origen desconocido» y abre el archivo.
