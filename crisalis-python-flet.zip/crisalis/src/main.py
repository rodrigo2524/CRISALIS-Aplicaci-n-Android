"""CRISALIS - «Es normal tener dudas». App móvil en Python (Flet)."""
import re
import time

import flet as ft

import data
import db

LILA, SOFT, BORDER, INK, MUTED = "#BAA0FF", "#F1ECFF", "#E4DBFF", "#3B2D66", "#6F6396"
AVISO = ("CRISALIS es una guía informativa y preventiva, no un diagnóstico. Si tienes dudas "
         "o malestar, platica con un familiar de confianza o un profesional de la salud.")


def txt(s, size=16, bold=False, color=INK, align=None):
    return ft.Text(s, size=size, color=color, text_align=align,
                   weight=ft.FontWeight.BOLD if bold else None)


def card(content, on_click=None):
    return ft.Container(content, bgcolor=SOFT, border=ft.border.all(1.5, BORDER),
                        border_radius=20, padding=16, on_click=on_click)


def button(label, on_click, primary=True):
    return ft.Container(txt(label, 17, True, align=ft.TextAlign.CENTER),
                        bgcolor=LILA if primary else SOFT, border=ft.border.all(1.5, BORDER),
                        border_radius=18, padding=15, alignment=ft.alignment.center,
                        on_click=on_click, ink=True)


def field(**kw):
    return ft.TextField(border_radius=14, border_color=BORDER, focused_border_color=LILA, color=INK, **kw)


class App:
    def __init__(self, page: ft.Page):
        self.page = page
        self.user = db.get_user()
        self.wipe_armed = False
        page.title = "CRISALIS"
        page.bgcolor = "#FFFFFF"
        page.padding = 0
        page.theme_mode = ft.ThemeMode.LIGHT
        page.theme = ft.Theme(color_scheme_seed=LILA)

    # ---------- estructura común ----------
    def show(self, title, body, back=True):
        head = ft.Container(
            bgcolor=LILA, padding=ft.padding.symmetric(vertical=6, horizontal=8),
            content=ft.Row([
                ft.IconButton(ft.Icons.ARROW_BACK, icon_color=INK, on_click=lambda e: self.home())
                if back else ft.Container(width=48),
                txt(title, 18, True),
                ft.TextButton(content=ft.Text(self.user["avatar"], size=24),
                              on_click=lambda e: self.profile()),
            ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN))
        foot = [ft.Divider(), txt(AVISO, 12, color=MUTED, align=ft.TextAlign.CENTER)]
        self.page.controls.clear()
        self.page.add(ft.SafeArea(expand=True, content=ft.Column(spacing=0, controls=[
            head, ft.Container(expand=True, padding=16,
                               content=ft.Column(body + foot, spacing=12, scroll=ft.ScrollMode.AUTO))])))
        self.page.update()

    # ---------- pantallas ----------
    def splash(self):
        self.page.add(ft.SafeArea(expand=True, content=ft.Column(
            [ft.Text("🦋", size=90), txt("CRISALIS", 32, True), txt("«Es normal tener dudas»", 16, color=MUTED)],
            alignment=ft.MainAxisAlignment.CENTER, horizontal_alignment=ft.CrossAxisAlignment.CENTER)))
        self.page.update()
        db.init()
        time.sleep(2)
        self.page.controls.clear()
        self.user = db.get_user()
        self.home() if self.user else self.login()

    def login(self):
        email = field(label="Correo de respaldo", keyboard_type=ft.KeyboardType.EMAIL)
        age = ft.Dropdown(label="Edad", value="12", border_radius=14, border_color=BORDER,
                          options=[ft.dropdown.Option(str(n)) for n in range(9, 18)])
        alias = field(label="Alias", hint_text="@cami00810", max_length=16)
        err = txt("", 14, True)
        chosen, boxes = {"i": 0}, []

        def pick(i):
            chosen["i"] = i
            for j, b in enumerate(boxes):
                b.border = ft.border.all(3 if j == i else 1.5, LILA if j == i else BORDER)
            self.page.update()

        for i, a in enumerate(data.AVATARS):
            boxes.append(ft.Container(ft.Text(a, size=28), width=56, height=56, border_radius=16,
                                      alignment=ft.alignment.center,
                                      border=ft.border.all(3 if i == 0 else 1.5, LILA if i == 0 else BORDER),
                                      on_click=lambda e, i=i: pick(i)))

        def enter(e):
            mail, al = email.value.strip(), re.sub(r"\s+", "", alias.value or "").lstrip("@")
            if not re.fullmatch(r"\S+@\S+\.\S+", mail):
                err.value = "Escribe un correo válido (solo como respaldo)."
            elif len(al) < 3:
                err.value = "Tu alias necesita al menos 3 caracteres."
            else:
                db.save_user(mail, int(age.value), "@" + al, data.AVATARS[chosen["i"]])
                self.user = db.get_user()
                return self.home()
            self.page.update()

        self.page.controls.clear()
        self.page.add(ft.SafeArea(expand=True, content=ft.Column(scroll=ft.ScrollMode.AUTO, spacing=12, controls=[
            ft.Container(padding=16, content=ft.Column(spacing=12, controls=[
                txt("🦋 Bienvenido/a a CRISALIS", 22, True),
                txt("Aquí eres anónimo/a: sin fotos ni nombre real.", 14, color=MUTED),
                card(ft.Column(spacing=12, controls=[
                    email, age, alias, txt("Elige tu avatar", 14, color=MUTED),
                    ft.Row(boxes, wrap=True, spacing=8, run_spacing=8), err,
                    button("Entrar anónimamente", enter)])),
                txt(AVISO, 12, color=MUTED, align=ft.TextAlign.CENTER)]))])))
        self.page.update()

    def home(self):
        db.touch_today()
        g = data.age_group(self.user["edad"])
        routes = {"hid": self.hydration, "mood": self.mood}
        tiles = []
        for key, (icon, title, sub) in data.MODULES.items():
            go = routes.get(key) or (lambda e, k=key: self.module(k))
            if key in routes:
                go = (lambda e, f=routes[key]: f())
            tiles.append(card(ft.Row([ft.Text(icon, size=32),
                                      ft.Column([txt(title, 18, True), txt(sub, 13, color=MUTED)], spacing=0)],
                                     spacing=14), on_click=go))
        self.show("CRISALIS", [txt(f"Hola, {self.user['alias']} {self.user['avatar']}", 22, True),
                               txt(f"Contenido para {data.GROUPS[g]}. «Es normal tener dudas».", 14, color=MUTED)] + tiles,
                  back=False)

    def module(self, key):
        g, done = data.age_group(self.user["edad"]), db.read_ids()
        items = [card(ft.Column([txt(a["t"], 17, True),
                                 txt("✓ Leído" if a["id"] in done else "Toca para leer", 13, color=MUTED)], spacing=0),
                      on_click=lambda e, a=a: self.article(a))
                 for a in data.ARTICLES if a["m"] == key and a["g"] == g]
        self.show(data.MODULES[key][1], [txt(f"Para {data.GROUPS[g]}", 13, color=MUTED)] + items)

    def article(self, a):
        def mark(e):
            db.mark_read(a["id"])
            self.article(a)
        done = a["id"] in db.read_ids()
        self.show(data.MODULES[a["m"]][1], [
            card(ft.Column([txt(a["t"], 20, True), txt(a["x"])], spacing=10)),
            button("✓ Ya lo leíste" if done else "Marcar como leído", mark),
            button("Volver a la lista", lambda e: self.module(a["m"]), primary=False)])

    def hydration(self):
        g, act, w = data.age_group(self.user["edad"]), db.get_activity(), db.get_water()
        ml = data.water_goal_ml(g, act)
        n = -(-ml // data.GLASS_ML)

        def set_act(i):
            db.set_activity(i)
            self.hydration()

        def glass(i):
            db.set_water(i if w == i + 1 else i + 1)
            self.hydration()

        chips = ft.Row([ft.Container(txt(x, 15), padding=ft.padding.symmetric(vertical=8, horizontal=14),
                                     border_radius=16, bgcolor=LILA if i == act else "#FFFFFF",
                                     border=ft.border.all(1.5, BORDER), on_click=lambda e, i=i: set_act(i))
                        for i, x in enumerate(data.ACTIVITY)], wrap=True)
        glasses = ft.Row([ft.Container(ft.Text("💧", size=22), width=44, height=52, border_radius=12,
                                       alignment=ft.alignment.center, bgcolor=LILA if i < w else "#FFFFFF",
                                       border=ft.border.all(1.5, BORDER), on_click=lambda e, i=i: glass(i))
                          for i in range(n)], wrap=True, spacing=8, run_spacing=8)
        self.show("Hidratación", [
            card(ft.Column([txt("Tu actividad física de hoy:"), chips,
                            txt(f"≈ {ml / 1000:.1f} litros de agua natural", 20, True),
                            txt(f"Orientación general para {data.GROUPS[g]}. En días de calor o con mucho movimiento, toma un poco más.", 13, color=MUTED)], spacing=10)),
            card(ft.Column([txt("Mis vasos de hoy (250 ml)", 16, True), txt(f"{w} de {n}", 13, color=MUTED), glasses], spacing=8))])

    def mood(self, saved=False):
        cur = db.get_mood()
        sel = {"v": cur["value"] if cur else None}
        note = field(label="Si quieres, escribe algo (solo tú lo ves)", multiline=True, min_lines=3,
                     max_length=200, value=cur["note"] if cur else "")
        msg, boxes = txt("Guardado en tu dispositivo ✓" if saved else "", 13, color=MUTED), []

        def pick(i):
            sel["v"] = i
            for j, b in enumerate(boxes):
                b.border = ft.border.all(3 if j == i else 1.5, LILA if j == i else BORDER)
            self.page.update()

        def save(e):
            if sel["v"] is not None:
                db.set_mood(sel["v"], (note.value or "").strip())
                self.mood(saved=True)

        for i, (emo, name) in enumerate(data.MOODS):
            boxes.append(ft.Container(ft.Column([ft.Text(emo, size=28), txt(name, 11, color=MUTED)], spacing=0,
                                                horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                                      width=62, padding=6, border_radius=16,
                                      border=ft.border.all(3 if sel["v"] == i else 1.5, LILA if sel["v"] == i else BORDER),
                                      on_click=lambda e, i=i: pick(i)))
        hist = [txt(f"{data.MOODS[m['value']][0]}  {m['day'][8:]}/{m['day'][5:7]} · {data.MOODS[m['value']][1]}"
                    + (f" — {m['note']}" if m["note"] else ""), 13, color=MUTED) for m in db.moods_last(7)]
        self.show("¿Qué tal hoy?", [
            card(ft.Column([txt("¿Cómo te sientes hoy?", 17, True), ft.Row(boxes, wrap=True, spacing=6, run_spacing=6),
                            note, button("Guardar mi día", save), msg], spacing=10)),
            card(ft.Column([txt("Mis últimos días", 16, True)] + (hist or [txt("Todavía no hay registros.", 13, color=MUTED)]), spacing=6))])

    def profile(self, edit=False, prog=False):
        u, n = self.user, len(db.read_ids())
        g, done = data.age_group(u["edad"]), db.read_ids()

        def stat(big, label):
            return ft.Container(ft.Column([txt(big, 24, True), txt(label, 12, color=MUTED)], spacing=0,
                                          horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                                bgcolor=SOFT, border_radius=16, padding=12, expand=True)

        na, err = field(label="Nuevo alias", value=u["alias"], max_length=16), txt("", 13, True)

        def save_alias(e):
            al = re.sub(r"\s+", "", na.value or "").lstrip("@")
            if len(al) < 3:
                err.value = "Mínimo 3 caracteres."
                return self.page.update()
            db.set_alias("@" + al)
            self.user = db.get_user()
            self.profile()

        def wipe(e):
            if not self.wipe_armed:
                self.wipe_armed = True
                return self.profile()
            self.wipe_armed = False
            db.wipe()
            self.user = None
            self.page.controls.clear()
            self.login()

        bars = []
        for k in ("cuerpo", "alim", "ejer"):
            arts = [a for a in data.ARTICLES if a["m"] == k and a["g"] == g]
            r = sum(a["id"] in done for a in arts)
            bars += [txt(f"{data.MODULES[k][0]} {data.MODULES[k][1]}: {r}/{len(arts)}", 13),
                     ft.ProgressBar(value=r / len(arts), color=LILA, bgcolor=SOFT)]
        faltan = 4 - n % 4
        body = [
            card(ft.Column([ft.Text(u["avatar"], size=72), txt(u["alias"], 22, True),
                            txt(f"Grupo {data.GROUPS[g]}", 13, color=MUTED)],
                           horizontal_alignment=ft.CrossAxisAlignment.CENTER, spacing=2)),
            ft.Row([stat(f"⭐ {data.level(n)}", "Nivel"), stat(f"🔥 {db.streak()}", "Racha (días)")]),
            ft.Row([stat(str(n), "Artículos leídos"), stat(str(db.days_count()), "Días en la app")]),
            card(ft.Column([txt(f"Faltan {faltan} lectura{'s' if faltan > 1 else ''} para el siguiente nivel", 13),
                            ft.ProgressBar(value=(n % 4) / 4, color=LILA, bgcolor="#FFFFFF")], spacing=6)),
            card(ft.Column([na, err, button("Guardar alias", save_alias)])) if edit
            else button("Editar alias", lambda e: self.profile(edit=True)),
            button("Mi progreso", lambda e: self.profile(prog=not prog), primary=False),
        ]
        if prog:
            body.append(card(ft.Column(bars, spacing=6)))
        body.append(button("Toca otra vez para borrar todo" if self.wipe_armed else "Borrar mis datos y salir",
                           wipe, primary=False))
        self.show("Mi perfil", body)


def main(page: ft.Page):
    App(page).splash()


if __name__ == "__main__":
    ft.app(target=main)
