"""Persistencia local con SQLite (modo offline-first). Todo queda en el dispositivo."""
import os
import sqlite3
from contextlib import closing
from datetime import date, timedelta


def _path() -> str:
    folder = os.getenv("FLET_APP_STORAGE_DATA") or os.path.dirname(os.path.abspath(__file__))
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, "crisalis.db")


def _q(sql, args=(), one=False, write=False):
    with closing(sqlite3.connect(_path())) as c:
        c.row_factory = sqlite3.Row
        cur = c.execute(sql, args)
        if write:
            c.commit()
            return None
        rows = cur.fetchall()
    return (rows[0] if rows else None) if one else rows


def init():
    for sql in (
        "CREATE TABLE IF NOT EXISTS user(id INTEGER PRIMARY KEY CHECK(id=1), email TEXT, edad INTEGER, alias TEXT, avatar TEXT)",
        "CREATE TABLE IF NOT EXISTS reads(article_id TEXT PRIMARY KEY)",
        "CREATE TABLE IF NOT EXISTS days(day TEXT PRIMARY KEY)",
        "CREATE TABLE IF NOT EXISTS moods(day TEXT PRIMARY KEY, value INTEGER, note TEXT)",
        "CREATE TABLE IF NOT EXISTS water(day TEXT PRIMARY KEY, glasses INTEGER)",
        "CREATE TABLE IF NOT EXISTS prefs(key TEXT PRIMARY KEY, value TEXT)",
    ):
        _q(sql, write=True)


def today() -> str:
    return date.today().isoformat()


def get_user():
    r = _q("SELECT * FROM user WHERE id=1", one=True)
    return dict(r) if r else None


def save_user(email, edad, alias, avatar):
    _q("INSERT OR REPLACE INTO user VALUES(1,?,?,?,?)", (email, edad, alias, avatar), write=True)


def set_alias(alias):
    _q("UPDATE user SET alias=? WHERE id=1", (alias,), write=True)


def mark_read(article_id):
    _q("INSERT OR IGNORE INTO reads VALUES(?)", (article_id,), write=True)


def read_ids() -> set:
    return {r["article_id"] for r in _q("SELECT article_id FROM reads")}


def touch_today():
    _q("INSERT OR IGNORE INTO days VALUES(?)", (today(),), write=True)


def days_count() -> int:
    return _q("SELECT COUNT(*) n FROM days", one=True)["n"]


def streak() -> int:
    used = {r["day"] for r in _q("SELECT day FROM days")}
    d, n = date.today(), 0
    if d.isoformat() not in used:
        d -= timedelta(days=1)
    while d.isoformat() in used:
        n += 1
        d -= timedelta(days=1)
    return n


def set_mood(value, note):
    _q("INSERT OR REPLACE INTO moods VALUES(?,?,?)", (today(), value, note), write=True)


def get_mood():
    r = _q("SELECT value, note FROM moods WHERE day=?", (today(),), one=True)
    return dict(r) if r else None


def moods_last(n=7):
    return [dict(r) for r in _q("SELECT day, value, note FROM moods ORDER BY day DESC LIMIT ?", (n,))]


def get_water() -> int:
    r = _q("SELECT glasses FROM water WHERE day=?", (today(),), one=True)
    return r["glasses"] if r else 0


def set_water(n):
    _q("INSERT OR REPLACE INTO water VALUES(?,?)", (today(), n), write=True)


def get_activity() -> int:
    r = _q("SELECT value FROM prefs WHERE key='act'", one=True)
    return int(r["value"]) if r else 0


def set_activity(i):
    _q("INSERT OR REPLACE INTO prefs VALUES('act',?)", (str(i),), write=True)


def wipe():
    for t in ("user", "reads", "days", "moods", "water", "prefs"):
        _q(f"DELETE FROM {t}", write=True)
