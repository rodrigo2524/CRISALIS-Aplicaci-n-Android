"""Contenido estático de CRISALIS (disponible sin conexión)."""

GROUPS = ["9–11 años", "12–14 años", "15–17 años"]
AVATARS = ["🦊", "🐼", "🐨", "🐰", "🦉", "🐢", "🦋", "🐙"]
MOODS = [("😊", "Feliz"), ("🙂", "Bien"), ("😐", "Normal"), ("😔", "Triste"), ("😟", "Inquieto/a")]
ACTIVITY = ["Baja", "Media", "Alta"]
WATER_BASE_ML = [1600, 1800, 2000]  # por grupo de edad
GLASS_ML = 250

MODULES = {
    "cuerpo": ("🌱", "Dudas sobre mi cuerpo", "Pubertad, acné, higiene"),
    "alim": ("🥑", "Alimentación", "Opciones económicas de la región"),
    "hid": ("💧", "Hidratación", "Cuánta agua tomar"),
    "ejer": ("🏃", "Ejercicio", "Rutinas para hacer en casa"),
    "mood": ("💜", "¿Qué tal hoy?", "Tu bitácora emocional privada"),
}

ARTICLES = [
    {"id": "c0a", "m": "cuerpo", "g": 0, "t": "Tu cuerpo empieza a cambiar",
     "x": "Entre los 9 y los 11 años muchos cuerpos empiezan a crecer más rápido, a sudar más y a oler distinto. Es normal que unos empiecen antes y otros después: cada cuerpo lleva su propio ritmo."},
    {"id": "c0b", "m": "cuerpo", "g": 0, "t": "Higiene diaria sencilla",
     "x": "Báñate a diario con agua y jabón, lávate bien las axilas, usa ropa limpia y cepíllate los dientes tres veces al día. Si tienes dudas, platícalo con un adulto de confianza."},
    {"id": "c1a", "m": "cuerpo", "g": 1, "t": "Acné: le pasa a casi todos",
     "x": "Los cambios hormonales hacen que la piel produzca más grasa. Lava tu cara con agua y jabón suave dos veces al día, no revientes los granitos y no compartas toallas. Si te preocupa mucho, consulta a un profesional de la salud."},
    {"id": "c1b", "m": "cuerpo", "g": 1, "t": "No te compares con las redes",
     "x": "Muchas fotos y videos en internet están editados o filtrados. Tu cuerpo no tiene que parecerse al de nadie más: está creciendo a su tiempo. Si algo te hace sentir mal, descansa de la pantalla y platícalo."},
    {"id": "c2a", "m": "cuerpo", "g": 2, "t": "Crecimiento y descanso",
     "x": "Dormir de 8 a 10 horas ayuda a crecer y a mantener el ánimo estable. Intenta acostarte a una hora parecida cada día y deja el celular un rato antes de dormir."},
    {"id": "c2b", "m": "cuerpo", "g": 2, "t": "Cuidar tu ánimo",
     "x": "Sentir altibajos es común en esta etapa. Hablar con alguien de confianza, moverte y descansar ayudan. Si la tristeza o la ansiedad duran muchos días, busca apoyo de un familiar, tu orientador o un profesional."},
    {"id": "a0", "m": "alim", "g": 0, "t": "Un plato colorido y económico",
     "x": "Combina frijoles, tortilla de maíz, huevo, calabaza, chayote y fruta de la región como plátano, naranja, mango o papaya. Variar colores ayuda a obtener más nutrientes sin gastar de más."},
    {"id": "a1", "m": "alim", "g": 1, "t": "Un desayuno que rinde",
     "x": "Un desayuno con huevo o frijoles, tortilla y fruta te da energía para la escuela. Prefiere agua natural a refrescos y no te saltes comidas: tu cuerpo está creciendo y las necesita."},
    {"id": "a2", "m": "alim", "g": 2, "t": "Comer bien con poco presupuesto",
     "x": "Frijol, lenteja, huevo, verduras de temporada, yuca y fruta local son opciones accesibles. Cocinar en casa y llevar tu lunch ayuda a ahorrar y a comer mejor. Evita las dietas de moda y pide orientación profesional."},
    {"id": "e0", "m": "ejer", "g": 0, "t": "Juego activo en casa",
     "x": "Brincar la cuerda, bailar, jugar a las estatuas o hacer una carrera de obstáculos: busca moverte cerca de 60 minutos al día entre juegos. Haz 5 minutos de calentamiento antes."},
    {"id": "e1", "m": "ejer", "g": 1, "t": "Rutina de 15 minutos",
     "x": "Calienta 3 min trotando en el lugar. Luego 10 sentadillas, 8 lagartijas apoyando rodillas, 20 s de plancha y 10 saltos de tijera. Repite 2 vueltas, estira y toma agua."},
    {"id": "e2", "m": "ejer", "g": 2, "t": "Circuito sin equipo",
     "x": "Calienta 5 min. Haz 3 vueltas de 12 sentadillas, 10 lagartijas, 15 zancadas, 30 s de plancha y 20 s de trote en el lugar. Estira al final. Si sientes dolor, detente y avisa a un adulto."},
]


def age_group(age: int) -> int:
    return 0 if age <= 11 else 1 if age <= 14 else 2


def level(articles_read: int) -> int:
    return 1 + articles_read // 4


def water_goal_ml(group: int, activity: int) -> int:
    return WATER_BASE_ML[group] + activity * 300
